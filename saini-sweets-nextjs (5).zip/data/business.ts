import { BusinessInfo } from "@/types";

/**
 * ALL editable business/brand content lives here.
 * Update this file to change contact details, story text, stats, nav links,
 * "Why Choose Us" points, or the festival list — no component code changes needed.
 *
 * Images referenced below are PLACEHOLDERS in /public/images.
 * Replace the files directly (keep the same filename) or update the path here.
 */
export const business: BusinessInfo = {
  name: "Saini Sweets",
  since: "1983",
  tagline:
    "Traditional mithai, made the way it has always been made — with pure khoya, real ghee, and four decades of practice.",
  shortTagline: "Handcrafted mithai, trusted since 1983.",
  logo: "/images/logo-placeholder.png",

  storyHeading: "Four decades at the same counter",
  storyParagraphs: [
    "Saini Sweets has been serving the neighbourhood since 1983 — long enough that regulars now bring their children in for the same kaju katli and rasgulla they grew up on.",
    "Every tray behind our counter is made fresh through the day, using traditional recipes that haven't changed since we opened. No shortcuts, no substitutes — just khoya, ghee, and time.",
    "We still weigh everything by hand, still use the same rate-list board style our founder started with, and still believe a sweet shop should feel like a neighbour, not a chain.",
  ],
  stats: [
    { value: "1983", label: "Established" },
    { value: "12+", label: "Signature Mithai" },
    { value: "40+", label: "Years of Trust" },
  ],

  // TODO: replace all placeholder contact details below with real information
  address: "Add your shop address here",
  addressLine2: "Add locality / landmark here",
  phone: "+91 00000 00000",
  whatsappNumber: "910000000000",
  whatsappMessage: "Hi Saini Sweets, I'd like to place an order.",
  email: "hello@sainisweets.example",
  hours: "Add your shop timings here",
  // TODO: replace with a real Google Maps embed URL for the shop's location
  mapEmbedSrc:
    "https://www.google.com/maps?q=Narela%2C+Delhi&output=embed",

  heroImage: "/images/hero-placeholder.jpg",
  aboutImage: "/images/about-placeholder.jpg",
  contactImage: "/images/contact-placeholder.jpg",

  navLinks: [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    { href: "/menu", label: "Menu" },
    { href: "/gallery", label: "Gallery" },
    { href: "/contact", label: "Contact" },
  ],

  socials: [
    { label: "Instagram", href: "#", icon: "Instagram" },
    { label: "Facebook", href: "#", icon: "Facebook" },
  ],

  whyChooseUs: [
    {
      id: "since-1983",
      icon: "Award",
      title: "Since 1983",
      description: "Four decades of trust, the same recipes, the same counter.",
    },
    {
      id: "pure-ingredients",
      icon: "Leaf",
      title: "Pure Ingredients",
      description: "Real khoya and ghee — no shortcuts, no substitutes, ever.",
    },
    {
      id: "fresh-daily",
      icon: "Flame",
      title: "Fresh Daily",
      description: "Every tray is made fresh through the day, not stocked for weeks.",
    },
    {
      id: "family-run",
      icon: "Users",
      title: "Family Run",
      description: "A neighbourhood shop, run the way it always has been — by hand.",
    },
  ],

  festivals: [
    {
      id: "diwali",
      name: "Diwali Specials",
      tagline: "Gift boxes and bulk orders for the festival of lights.",
      image: "/images/festival-placeholder.jpg",
    },
    {
      id: "raksha-bandhan",
      name: "Raksha Bandhan",
      tagline: "Sweet boxes made for gifting, ready ahead of the day.",
      image: "/images/festival-placeholder.jpg",
    },
    {
      id: "weddings",
      name: "Weddings & Events",
      tagline: "Bulk orders for celebrations, with advance booking.",
      image: "/images/festival-placeholder.jpg",
    },
  ],
};
