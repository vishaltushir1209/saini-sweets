import { PageSeo } from "@/types";
import { business } from "./business";

/**
 * Per-page SEO metadata. Edit titles/descriptions/keywords here —
 * app/**\/page.tsx files just import and re-export these, no copy lives in the pages.
 */
const siteName = business.name;
const defaultOgImage = "/images/og-placeholder.jpg";

export const seo: Record<"home" | "about" | "menu" | "gallery" | "contact", PageSeo> = {
  home: {
    title: `${siteName} — Traditional Mithai Since ${business.since}`,
    description: business.tagline,
    keywords: ["mithai", "sweet shop", "indian sweets", "saini sweets", "kaju katli", "gulab jamun"],
    ogImage: defaultOgImage,
  },
  about: {
    title: `About Us — ${siteName}`,
    description: business.storyParagraphs[0],
    keywords: ["saini sweets history", "about saini sweets", "since 1983 sweet shop"],
    ogImage: defaultOgImage,
  },
  menu: {
    title: `Menu & Rate List — ${siteName}`,
    description: `Full mithai rate list from ${siteName}, priced per kg — fresh daily.`,
    keywords: ["mithai price list", "sweet shop menu", "kaju katli price", "rasgulla price"],
    ogImage: defaultOgImage,
  },
  gallery: {
    title: `Gallery — ${siteName}`,
    description: `A look inside ${siteName} — the shop, the counter, and the mithai.`,
    keywords: ["saini sweets photos", "mithai shop gallery"],
    ogImage: defaultOgImage,
  },
  contact: {
    title: `Contact & Location — ${siteName}`,
    description: `Visit ${siteName}, call ahead, or message us on WhatsApp for bulk and festival orders.`,
    keywords: ["saini sweets contact", "saini sweets location", "sweet shop near me"],
    ogImage: defaultOgImage,
  },
};
