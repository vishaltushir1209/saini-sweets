import { Review } from "@/types";

/**
 * Customer testimonials shown on the homepage.
 * ⚠️ SAMPLE PLACEHOLDER CONTENT — these are example reviews, not real customers.
 * Replace `name` and `quote` with real customer feedback before launch.
 */
export const reviews: Review[] = [
  {
    id: "review-1",
    name: "Placeholder Customer 1",
    quote:
      "Sample review text — replace with a real customer quote about the mithai quality or service.",
    rating: 5,
  },
  {
    id: "review-2",
    name: "Placeholder Customer 2",
    quote:
      "Sample review text — replace with a real customer quote about a festival or bulk order experience.",
    rating: 5,
  },
  {
    id: "review-3",
    name: "Placeholder Customer 3",
    quote:
      "Sample review text — replace with a real customer quote about freshness or a favourite sweet.",
    rating: 4,
  },
];
