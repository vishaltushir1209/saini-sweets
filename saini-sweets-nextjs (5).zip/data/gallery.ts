import { GalleryImage } from "@/types";

/**
 * Images shown in the Gallery section (homepage preview + full /gallery page).
 * `size: "large"` makes an image span two grid rows on desktop.
 * All files below are PLACEHOLDERS in /public/images — replace the files
 * directly (same filename) once real shop/product photos are available.
 * `alt` text describes the intended photo content for screen readers — update
 * it to match whatever real photo replaces each placeholder.
 */
export const galleryImages: GalleryImage[] = [
  { id: "gallery-1", src: "/images/gallery-1.jpg", alt: "Saini Sweets storefront", size: "large" },
  { id: "gallery-2", src: "/images/gallery-2.jpg", alt: "Saini Sweets display counter" },
  { id: "gallery-3", src: "/images/gallery-3.jpg", alt: "Fresh mithai trays at Saini Sweets" },
  { id: "gallery-4", src: "/images/gallery-4.jpg", alt: "Saini Sweets shop interior" },
  { id: "gallery-5", src: "/images/gallery-5.jpg", alt: "Saini Sweets rate list board" },
];
