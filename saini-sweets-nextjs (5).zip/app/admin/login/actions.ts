"use server";

import { AuthError } from "next-auth";
import { signIn } from "@/auth";

/**
 * Server Action backing the login form. `signIn` throws a special redirect
 * signal on success (which must propagate, not be caught as an error) and an
 * `AuthError` on invalid credentials, which we turn into a friendly message.
 */
export async function loginAction(
  _prevState: string | undefined,
  formData: FormData
): Promise<string | undefined> {
  try {
    await signIn("credentials", {
      email: formData.get("email"),
      password: formData.get("password"),
      redirectTo: "/admin/dashboard",
    });
    return undefined;
  } catch (error) {
    if (error instanceof AuthError) {
      return "Incorrect email or password.";
    }
    // Re-throw Next.js's internal redirect signal so a successful login still redirects.
    throw error;
  }
}
