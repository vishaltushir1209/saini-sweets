import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { Monogram } from "@/components/Monogram";
import { LoginForm } from "@/components/admin/LoginForm";

export const metadata: Metadata = {
  title: "Admin Login",
};

export default async function AdminLoginPage() {
  const session = await auth();
  if (session) {
    redirect("/admin/dashboard");
  }

  return (
    <div className="flex flex-col items-center px-4 py-8">
      <Monogram size={44} className="mb-6" />
      <h1 className="mb-2 text-center font-cormorant text-4xl text-cream">Admin Sign In</h1>
      <p className="mb-10 text-center text-sm text-cream-dim">
        Restricted access — Saini Sweets staff only.
      </p>
      <LoginForm />
    </div>
  );
}
