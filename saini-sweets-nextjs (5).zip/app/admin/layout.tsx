import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Admin",
  // Keep the whole admin section out of search results.
  robots: { index: false, follow: false },
};

/**
 * Outer shell for all of /admin, including /admin/login and the bare /admin
 * redirect page — those must stay reachable without a session, so the
 * protected sidebar/topbar (and the session check) live one level deeper,
 * in app/admin/(protected)/layout.tsx, not here.
 */
export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <div className="min-h-screen bg-ink text-cream">{children}</div>;
}
