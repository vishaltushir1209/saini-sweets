import type { Metadata } from "next";
import { Settings } from "lucide-react";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { ComingSoon } from "@/components/admin/ComingSoon";

export const metadata: Metadata = {
  title: "Settings",
};

export default function AdminSettingsPage() {
  return (
    <div>
      <Breadcrumb items={[{ label: "Dashboard", href: "/admin/dashboard" }, { label: "Settings" }]} />
      <h1 className="mb-8 mt-4 font-cormorant text-4xl text-cream md:text-5xl">Settings</h1>
      <ComingSoon
        icon={Settings}
        title="Business settings are coming soon"
        description="Editing contact details, hours, and business info will live here."
      />
    </div>
  );
}
