import type { Metadata } from "next";
import { Package, Image as ImageIcon, Star, PartyPopper, Settings } from "lucide-react";
import { auth } from "@/auth";
import { getProducts } from "@/lib/products-store";
import { galleryImages } from "@/data/gallery";
import { reviews } from "@/data/reviews";
import { business } from "@/data/business";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { StatCard } from "@/components/admin/StatCard";
import { QuickActionCard } from "@/components/admin/QuickActionCard";

export const metadata: Metadata = {
  title: "Dashboard",
};

const QUICK_ACTIONS = [
  { href: "/admin/products", icon: Package, title: "Products", description: "View and manage the mithai menu." },
  { href: "/admin/gallery", icon: ImageIcon, title: "Gallery", description: "View and manage shop photos." },
  { href: "/admin/reviews", icon: Star, title: "Reviews", description: "View and manage customer testimonials." },
  { href: "/admin/settings", icon: Settings, title: "Settings", description: "Update business details and contact info." },
];

export default async function AdminDashboardPage() {
  // Layout already guarantees a session exists; fetched again here only to
  // greet the admin by email, not to re-gate the page.
  const session = await auth();
  const products = await getProducts();

  const stats = [
    { icon: Package, label: "Products", value: String(products.length) },
    { icon: ImageIcon, label: "Gallery Photos", value: String(galleryImages.length) },
    { icon: Star, label: "Reviews", value: String(reviews.length) },
    { icon: PartyPopper, label: "Festival Campaigns", value: String(business.festivals.length) },
  ];

  return (
    <div>
      <Breadcrumb items={[{ label: "Dashboard" }]} />

      <div className="mb-10 mt-4">
        <h1 className="font-cormorant text-4xl text-cream md:text-5xl">Welcome back</h1>
        <p className="mt-2 text-cream-dim">Signed in as {session?.user?.email}</p>
      </div>

      <section aria-labelledby="overview-heading" className="mb-14">
        <h2 id="overview-heading" className="mb-5 font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
          Overview
        </h2>
        <ul className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((stat) => (
            <li key={stat.label}>
              <StatCard {...stat} />
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="quick-actions-heading">
        <h2 id="quick-actions-heading" className="mb-5 font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
          Quick Actions
        </h2>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {QUICK_ACTIONS.map((action) => (
            <li key={action.href}>
              <QuickActionCard {...action} />
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
