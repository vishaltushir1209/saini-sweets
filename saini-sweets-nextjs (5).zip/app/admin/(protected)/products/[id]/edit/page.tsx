import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getProduct } from "@/lib/products-store";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { ProductForm } from "@/components/admin/products/ProductForm";
import { updateProductAction } from "@/app/admin/(protected)/products/actions";

interface EditProductPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: EditProductPageProps): Promise<Metadata> {
  const { id } = await params;
  const product = await getProduct(id);
  return { title: product ? `Edit ${product.name}` : "Edit Product" };
}

export default async function EditProductPage({ params }: EditProductPageProps) {
  const { id } = await params;
  const product = await getProduct(id);

  if (!product) {
    notFound();
  }

  const action = updateProductAction.bind(null, product.id);

  return (
    <div>
      <Breadcrumb
        items={[
          { label: "Dashboard", href: "/admin/dashboard" },
          { label: "Products", href: "/admin/products" },
          { label: product.name },
        ]}
      />
      <h1 className="mb-8 mt-4 font-cormorant text-4xl text-cream md:text-5xl">Edit Product</h1>
      <ProductForm mode="edit" product={product} action={action} />
    </div>
  );
}
