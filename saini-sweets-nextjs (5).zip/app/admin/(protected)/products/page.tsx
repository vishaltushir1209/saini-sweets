import type { Metadata } from "next";
import { getProducts } from "@/lib/products-store";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { ProductsListClient } from "@/components/admin/products/ProductsListClient";

export const metadata: Metadata = {
  title: "Products",
};

export default async function AdminProductsPage() {
  const products = await getProducts();

  return (
    <div>
      <Breadcrumb items={[{ label: "Dashboard", href: "/admin/dashboard" }, { label: "Products" }]} />
      <h1 className="mb-8 mt-4 font-cormorant text-4xl text-cream md:text-5xl">Products</h1>
      <ProductsListClient initialProducts={products} />
    </div>
  );
}
