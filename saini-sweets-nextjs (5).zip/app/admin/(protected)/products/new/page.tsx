import type { Metadata } from "next";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { ProductForm } from "@/components/admin/products/ProductForm";
import { createProductAction } from "@/app/admin/(protected)/products/actions";

export const metadata: Metadata = {
  title: "Add Product",
};

export default function NewProductPage() {
  return (
    <div>
      <Breadcrumb
        items={[
          { label: "Dashboard", href: "/admin/dashboard" },
          { label: "Products", href: "/admin/products" },
          { label: "Add Product" },
        ]}
      />
      <h1 className="mb-8 mt-4 font-cormorant text-4xl text-cream md:text-5xl">Add Product</h1>
      <ProductForm mode="create" action={createProductAction} />
    </div>
  );
}
