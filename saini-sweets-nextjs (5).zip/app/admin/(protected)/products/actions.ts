"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import {
  createProduct,
  updateProduct,
  deleteProduct,
  getProduct,
} from "@/lib/products-store";
import { validateProductInput } from "@/lib/validate-product";
import { saveProductImage } from "@/lib/product-image-upload";

export interface ProductFormState {
  errors: Record<string, string>;
}

function revalidateProductPages() {
  revalidatePath("/admin/products");
  revalidatePath("/menu");
  revalidatePath("/");
}

export async function createProductAction(
  _prevState: ProductFormState,
  formData: FormData
): Promise<ProductFormState> {
  const { errors, data } = validateProductInput(formData);
  if (!data) return { errors };

  const imageFile = formData.get("image");
  let imagePath: string | undefined;
  if (imageFile instanceof File && imageFile.size > 0) {
    const result = await saveProductImage(imageFile, data.name);
    if (result.error) return { errors: { image: result.error } };
    imagePath = result.path;
  }

  await createProduct({ ...data, image: imagePath });
  revalidateProductPages();
  redirect("/admin/products");
}

export async function updateProductAction(
  id: string,
  _prevState: ProductFormState,
  formData: FormData
): Promise<ProductFormState> {
  const existing = await getProduct(id);
  if (!existing) {
    return { errors: { form: "This product no longer exists." } };
  }

  const { errors, data } = validateProductInput(formData);
  if (!data) return { errors };

  let imagePath = existing.image;
  const imageFile = formData.get("image");
  if (imageFile instanceof File && imageFile.size > 0) {
    const result = await saveProductImage(imageFile, data.name);
    if (result.error) return { errors: { image: result.error } };
    imagePath = result.path;
  }

  await updateProduct(id, { ...data, image: imagePath });
  revalidateProductPages();
  redirect("/admin/products");
}

export async function deleteProductAction(id: string): Promise<{ error?: string }> {
  const deleted = await deleteProduct(id);
  if (!deleted) return { error: "Product not found." };
  revalidateProductPages();
  return {};
}

export async function toggleProductFlagAction(
  id: string,
  field: "featured" | "available"
): Promise<{ error?: string }> {
  const product = await getProduct(id);
  if (!product) return { error: "Product not found." };
  await updateProduct(id, { [field]: !product[field] });
  revalidateProductPages();
  return {};
}
