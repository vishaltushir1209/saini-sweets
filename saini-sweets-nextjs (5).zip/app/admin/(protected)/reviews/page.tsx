import type { Metadata } from "next";
import { Star } from "lucide-react";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { ComingSoon } from "@/components/admin/ComingSoon";

export const metadata: Metadata = {
  title: "Reviews",
};

export default function AdminReviewsPage() {
  return (
    <div>
      <Breadcrumb items={[{ label: "Dashboard", href: "/admin/dashboard" }, { label: "Reviews" }]} />
      <h1 className="mb-8 mt-4 font-cormorant text-4xl text-cream md:text-5xl">Reviews</h1>
      <ComingSoon
        icon={Star}
        title="Review management is coming soon"
        description="Approving and curating customer testimonials will live here."
      />
    </div>
  );
}
