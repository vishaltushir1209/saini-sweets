import type { Metadata } from "next";
import { Image as ImageIcon } from "lucide-react";
import { Breadcrumb } from "@/components/admin/Breadcrumb";
import { ComingSoon } from "@/components/admin/ComingSoon";

export const metadata: Metadata = {
  title: "Gallery",
};

export default function AdminGalleryPage() {
  return (
    <div>
      <Breadcrumb items={[{ label: "Dashboard", href: "/admin/dashboard" }, { label: "Gallery" }]} />
      <h1 className="mb-8 mt-4 font-cormorant text-4xl text-cream md:text-5xl">Gallery</h1>
      <ComingSoon
        icon={ImageIcon}
        title="Gallery management is coming soon"
        description="Uploading and organizing shop photos will live here."
      />
    </div>
  );
}
