import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { AdminShell } from "@/components/admin/AdminShell";

/**
 * Shared layout for every protected admin page (dashboard/products/gallery/
 * reviews/settings). The session check lives here — once — rather than being
 * repeated in each page. /admin/login and the bare /admin redirect page sit
 * outside this route group so they're never subject to this check.
 */
export default async function ProtectedAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();
  if (!session) {
    redirect("/admin/login");
  }

  return <AdminShell userEmail={session.user?.email ?? undefined}>{children}</AdminShell>;
}
