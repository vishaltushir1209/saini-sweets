import Link from "next/link";
import { Button } from "@/components/ui/button";

/** Shown for any /admin/(protected) route that calls notFound(), e.g. an unknown product id. */
export default function AdminNotFound() {
  return (
    <div className="flex flex-col items-center border border-gold/25 bg-charcoal px-6 py-20 text-center">
      <h1 className="font-cormorant text-3xl text-cream">Not Found</h1>
      <p className="mt-2 max-w-sm text-sm text-cream-dim">
        The item you&apos;re looking for doesn&apos;t exist or may have been deleted.
      </p>
      <Button asChild variant="gold" size="sm" className="mt-6">
        <Link href="/admin/products">Back to Products</Link>
      </Button>
    </div>
  );
}
