import { redirect } from "next/navigation";
import { auth } from "@/auth";

/** Bare /admin visits go to the dashboard if signed in, otherwise to login. */
export default async function AdminIndexPage() {
  const session = await auth();
  redirect(session ? "/admin/dashboard" : "/admin/login");
}
