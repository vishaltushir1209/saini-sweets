import type { Metadata } from "next";
import { Cormorant_Garamond, Cinzel, EB_Garamond } from "next/font/google";
import "./globals.css";
import { MotionProvider } from "@/components/MotionProvider";
import { business } from "@/data/business";
import { seo } from "@/data/seo";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const cinzel = Cinzel({
  subsets: ["latin"],
  weight: ["500", "600"],
  variable: "--font-cinzel",
  display: "swap",
});

const ebGaramond = EB_Garamond({
  subsets: ["latin"],
  weight: ["400", "500"],
  style: ["normal", "italic"],
  variable: "--font-eb-garamond",
  display: "swap",
});

export const metadata: Metadata = {
  // TODO: replace with the real production domain once deployed
  metadataBase: new URL("https://saini-sweets.example.com"),
  title: {
    default: seo.home.title,
    template: `%s — ${business.name}`,
  },
  description: seo.home.description,
  keywords: seo.home.keywords,
  openGraph: {
    title: seo.home.title,
    description: seo.home.description,
    images: [seo.home.ogImage],
    siteName: business.name,
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: seo.home.title,
    description: seo.home.description,
    images: [seo.home.ogImage],
  },
};

/**
 * Root layout — truly global shell only (html/body/fonts/motion config).
 * The public site's Header/Footer live in app/(site)/layout.tsx; the admin
 * area has its own shell in app/admin/layout.tsx. Neither is rendered here
 * so /admin never shows the public marketing nav/footer.
 */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${cormorant.variable} ${cinzel.variable} ${ebGaramond.variable} bg-ink font-serif text-cream antialiased`}
      >
        <MotionProvider>{children}</MotionProvider>
      </body>
    </html>
  );
}
