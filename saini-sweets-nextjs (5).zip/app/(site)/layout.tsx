import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

/**
 * Layout for every public marketing page (Home/About/Menu/Gallery/Contact).
 * Kept separate from the root layout so the /admin section can have its own
 * shell without the public site's Header/Footer/nav.
 */
export default function SiteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-gold focus:px-4 focus:py-2 focus:font-cinzel focus:text-xs focus:uppercase focus:tracking-widest focus:text-ink"
      >
        Skip to content
      </a>
      <Header />
      <main id="main-content">{children}</main>
      <Footer />
    </>
  );
}
