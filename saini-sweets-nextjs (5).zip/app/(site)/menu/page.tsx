import type { Metadata } from "next";
import { seo } from "@/data/seo";
import { getProducts } from "@/lib/products-store";
import { PageHeader } from "@/components/PageHeader";
import { MenuBoard } from "@/components/MenuBoard";
import { FestivalOrders } from "@/components/FestivalOrders";

export const metadata: Metadata = {
  title: seo.menu.title,
  description: seo.menu.description,
  keywords: seo.menu.keywords,
  openGraph: {
    title: seo.menu.title,
    description: seo.menu.description,
    images: [seo.menu.ogImage],
  },
  twitter: {
    card: "summary_large_image",
    title: seo.menu.title,
    description: seo.menu.description,
    images: [seo.menu.ogImage],
  },
};

export default async function MenuPage() {
  const products = await getProducts();

  return (
    <>
      <PageHeader
        eyebrow="What We Make"
        title="Our Menu"
        description="Fresh daily, priced honestly, sold by the kilo — just as it's always been."
      />
      <MenuBoard products={products} />
      <FestivalOrders />
    </>
  );
}
