import type { Metadata } from "next";
import { seo } from "@/data/seo";
import { PageHeader } from "@/components/PageHeader";
import { Contact } from "@/components/Contact";
import { GoogleMap } from "@/components/GoogleMap";
import { ContactCTA } from "@/components/ContactCTA";

export const metadata: Metadata = {
  title: seo.contact.title,
  description: seo.contact.description,
  keywords: seo.contact.keywords,
  openGraph: {
    title: seo.contact.title,
    description: seo.contact.description,
    images: [seo.contact.ogImage],
  },
  twitter: {
    card: "summary_large_image",
    title: seo.contact.title,
    description: seo.contact.description,
    images: [seo.contact.ogImage],
  },
};

export default function ContactPage() {
  return (
    <>
      <PageHeader
        eyebrow="Visit Us"
        title="Get In Touch"
        description="Drop by the shop, or reach out ahead for bulk and gifting orders."
      />
      <Contact />
      <GoogleMap />
      <ContactCTA />
    </>
  );
}
