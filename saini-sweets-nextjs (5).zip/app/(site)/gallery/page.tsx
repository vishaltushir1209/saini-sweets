import type { Metadata } from "next";
import { seo } from "@/data/seo";
import { PageHeader } from "@/components/PageHeader";
import { Gallery } from "@/components/Gallery";

export const metadata: Metadata = {
  title: seo.gallery.title,
  description: seo.gallery.description,
  keywords: seo.gallery.keywords,
  openGraph: {
    title: seo.gallery.title,
    description: seo.gallery.description,
    images: [seo.gallery.ogImage],
  },
  twitter: {
    card: "summary_large_image",
    title: seo.gallery.title,
    description: seo.gallery.description,
    images: [seo.gallery.ogImage],
  },
};

export default function GalleryPage() {
  return (
    <>
      <PageHeader
        eyebrow="Take A Look"
        title="Gallery"
        description="A look inside the shop, the counter, and the mithai."
      />
      <Gallery />
    </>
  );
}
