import type { Metadata } from "next";
import { seo } from "@/data/seo";
import { getProducts } from "@/lib/products-store";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { FeaturedProducts } from "@/components/FeaturedProducts";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { FestivalOrders } from "@/components/FestivalOrders";
import { Gallery } from "@/components/Gallery";
import { Testimonials } from "@/components/Testimonials";
import { GoogleMap } from "@/components/GoogleMap";
import { ContactCTA } from "@/components/ContactCTA";

export const metadata: Metadata = {
  title: seo.home.title,
  description: seo.home.description,
  keywords: seo.home.keywords,
};

export default async function HomePage() {
  const products = await getProducts();

  return (
    <>
      <Hero />
      <About variant="teaser" />
      <FeaturedProducts products={products} />
      <WhyChooseUs />
      <FestivalOrders />
      <Gallery limit={5} showCta />
      <Testimonials />
      <GoogleMap />
      <ContactCTA />
    </>
  );
}
