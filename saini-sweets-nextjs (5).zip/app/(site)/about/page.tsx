import type { Metadata } from "next";
import { seo } from "@/data/seo";
import { PageHeader } from "@/components/PageHeader";
import { About } from "@/components/About";
import { WhyChooseUs } from "@/components/WhyChooseUs";

export const metadata: Metadata = {
  title: seo.about.title,
  description: seo.about.description,
  keywords: seo.about.keywords,
  openGraph: {
    title: seo.about.title,
    description: seo.about.description,
    images: [seo.about.ogImage],
  },
  twitter: {
    card: "summary_large_image",
    title: seo.about.title,
    description: seo.about.description,
    images: [seo.about.ogImage],
  },
};

export default function AboutPage() {
  return (
    <>
      <PageHeader
        eyebrow="Our Story"
        title="About Saini Sweets"
        description="Four decades of tradition, one counter, no shortcuts."
      />
      <About variant="full" />
      <WhyChooseUs />
    </>
  );
}
