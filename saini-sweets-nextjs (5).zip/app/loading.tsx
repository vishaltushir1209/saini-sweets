import { Monogram } from "@/components/Monogram";

/**
 * Next.js App Router route-transition loading state — shown automatically
 * while a page segment loads. Uses the same monogram mark as the rest of
 * the brand so a transition never feels like a generic spinner.
 */
export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-ink">
      <Monogram size={48} className="animate-pulse" />
    </div>
  );
}
