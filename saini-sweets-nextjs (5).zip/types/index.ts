export type MenuIconName =
  | "circle"
  | "dot3"
  | "diamond"
  | "square"
  | "layered"
  | "oval"
  | "ball2"
  | "box"
  | "pretzel";

export const PRODUCT_CATEGORIES = [
  "Burfi & Barfi",
  "Peda",
  "Laddu",
  "Syrup Sweets",
  "Dry Sweets",
  "Gift Boxes",
] as const;

export type ProductCategory = (typeof PRODUCT_CATEGORIES)[number];

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string; // e.g. "kg"
  icon: MenuIconName;
  /** Optional real product photo (public/uploads/products/...). Falls back to the vector icon when absent. */
  image?: string;
  /** Shown in the homepage "Featured Products" section when true. */
  featured?: boolean;
  /** Whether the product is currently available for sale. Defaults to true when absent. */
  available?: boolean;
  category?: ProductCategory;
  description?: string;
}

export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  /** "large" spans two grid rows on desktop, "normal" is a single cell */
  size?: "large" | "normal";
}

export interface StatItem {
  value: string;
  label: string;
}

export interface Feature {
  id: string;
  /** lucide-react icon component name, e.g. "Award" */
  icon: string;
  title: string;
  description: string;
}

export interface Festival {
  id: string;
  name: string;
  tagline: string;
  image: string;
}

export interface Review {
  id: string;
  name: string;
  quote: string;
  rating: number; // 1-5
}

export interface NavLink {
  href: string;
  label: string;
}

export interface SocialLink {
  label: string;
  href: string;
  /** lucide-react icon component name, e.g. "Instagram" */
  icon: string;
}

export interface BusinessInfo {
  name: string;
  since: string;
  tagline: string;
  shortTagline: string;
  logo: string;

  storyHeading: string;
  storyParagraphs: string[];
  stats: StatItem[];

  address: string;
  addressLine2: string;
  phone: string;
  whatsappNumber: string;
  whatsappMessage: string;
  email: string;
  hours: string;
  mapEmbedSrc: string;

  heroImage: string;
  aboutImage: string;
  contactImage: string;

  navLinks: NavLink[];
  socials: SocialLink[];

  whyChooseUs: Feature[];
  festivals: Festival[];
}

/** Per-page SEO metadata, keyed by route. */
export interface PageSeo {
  title: string;
  description: string;
  keywords: string[];
  ogImage: string;
}
