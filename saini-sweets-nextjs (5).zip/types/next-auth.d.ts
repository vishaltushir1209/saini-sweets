import type { DefaultSession } from "next-auth";

/** Extends Auth.js's default session typing to reflect our single-admin user shape. */
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
    } & DefaultSession["user"];
  }
}
