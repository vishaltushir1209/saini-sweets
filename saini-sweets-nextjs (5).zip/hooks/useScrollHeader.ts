"use client";

import { useEffect, useState } from "react";

/**
 * Returns true once the page has been scrolled past `threshold` px.
 * Used by the Header component to switch to a solid background.
 */
export function useScrollHeader(threshold = 40): boolean {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > threshold);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [threshold]);

  return scrolled;
}
