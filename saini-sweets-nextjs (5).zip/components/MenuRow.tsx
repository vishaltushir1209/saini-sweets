import { Product } from "@/types";
import { formatPrice } from "@/lib/utils";
import { ProductMedia } from "@/components/ProductMedia";

interface MenuRowProps {
  product: Product;
}

/** A single row in the rate-list board. Always rendered as a child of a <ul> in MenuBoard. */
export function MenuRow({ product }: MenuRowProps) {
  return (
    <li className="flex items-center gap-4 border-b border-dotted border-cream-dim/30 py-[18px] last:border-b-0">
      <div className="h-10 w-10 flex-none">
        <ProductMedia product={product} className="h-full w-full" imageSizes="40px" rounded />
      </div>
      <div className="flex-1 font-cormorant text-xl text-cream">{product.name}</div>
      <div className="whitespace-nowrap font-cinzel text-sm text-gold-light">
        {formatPrice(product.price)}
        <span className="ml-0.5 text-[11px] text-cream-dim">/{product.unit}</span>
      </div>
    </li>
  );
}
