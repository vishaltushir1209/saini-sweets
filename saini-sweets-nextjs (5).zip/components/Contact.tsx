"use client";

import { motion } from "framer-motion";
import { MapPin, Phone, Clock, Mail } from "lucide-react";
import { business } from "@/data/business";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

const CONTACT_CARDS = [
  { icon: MapPin, label: "Address", value: `${business.address}, ${business.addressLine2}` },
  { icon: Phone, label: "Phone", value: business.phone },
  { icon: Clock, label: "Hours", value: business.hours },
  { icon: Mail, label: "Email", value: business.email },
];

/** Contact info cards — full address/phone/hours/email. Used on the /contact page. */
export function Contact() {
  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-5xl">
        <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {CONTACT_CARDS.map((card, i) => (
            <motion.li
              key={card.label}
              {...fadeUpViewport}
              transition={fadeUpTransition(i, 0.08)}
              className="border-t border-gold-dim pt-5 text-left"
            >
              <card.icon size={20} className="mb-3 text-gold" aria-hidden="true" />
              <span className="mb-2 block font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
                {card.label}
              </span>
              <p className="text-cream-dim">{card.value}</p>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}
