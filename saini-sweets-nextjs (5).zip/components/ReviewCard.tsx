import { Star, Quote } from "lucide-react";
import { Review } from "@/types";

interface ReviewCardProps {
  review: Review;
}

/** Card System → Review Card. */
export function ReviewCard({ review }: ReviewCardProps) {
  return (
    <article className="border border-gold/25 bg-charcoal p-8 text-left shadow-depth-sm">
      <Quote size={22} className="mb-4 text-gold" aria-hidden="true" />
      <p className="mb-6 font-serif text-lg italic text-cream-dim">&ldquo;{review.quote}&rdquo;</p>
      <div className="flex items-center justify-between">
        <span className="font-cinzel text-xs uppercase tracking-[0.14em] text-cream">
          {review.name}
        </span>
        <div className="flex gap-0.5" aria-label={`${review.rating} out of 5 stars`}>
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              size={14}
              className={i < review.rating ? "fill-gold text-gold" : "text-gold-dim"}
              aria-hidden="true"
            />
          ))}
        </div>
      </div>
    </article>
  );
}
