"use client";

import { motion } from "framer-motion";
import { Product } from "@/types";
import { MenuRow } from "@/components/MenuRow";

interface MenuBoardProps {
  products: Product[];
}

/** Full rate-list board — used on the dedicated /menu page. Data passed from the page's server fetch. */
export function MenuBoard({ products }: MenuBoardProps) {
  const available = products.filter((p) => p.available ?? true);
  const mid = Math.ceil(available.length / 2);
  const left = available.slice(0, mid);
  const right = available.slice(mid);

  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-4xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="border border-gold-dim p-1.5"
        >
          <div className="border border-gold/35 px-[5%] py-11">
            <div className="mb-9 border-b border-gold/30 pb-6 text-center font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
              Rate List &nbsp;·&nbsp; Per Kg
            </div>
            <div className="grid gap-x-16 text-left md:grid-cols-2">
              <ul className="flex flex-col">
                {left.map((product) => (
                  <MenuRow key={product.id} product={product} />
                ))}
              </ul>
              <ul className="flex flex-col">
                {right.map((product) => (
                  <MenuRow key={product.id} product={product} />
                ))}
              </ul>
            </div>
          </div>
        </motion.div>

        <p className="mt-8 font-serif text-sm italic text-cream-dim">
          Prices per kg · Half-kg &amp; boxed gifting available on request
        </p>
      </div>
    </section>
  );
}
