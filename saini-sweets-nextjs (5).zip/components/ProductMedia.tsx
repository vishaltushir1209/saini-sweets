import Image from "next/image";
import { Product } from "@/types";
import { MenuIcon } from "@/components/icons/MenuIcons";
import { cn } from "@/lib/utils";

interface ProductMediaProps {
  product: Product;
  className?: string;
  /** Passed straight to next/image `sizes` — required so small thumbnails don't request a full-width image. */
  imageSizes: string;
  rounded?: boolean;
}

/**
 * Renders a product's real photo when `product.image` is set, otherwise falls
 * back to its vector medallion. Shared by MenuRow and ProductCard, which
 * previously duplicated this exact branch.
 */
export function ProductMedia({ product, className, imageSizes, rounded = false }: ProductMediaProps) {
  if (product.image) {
    return (
      <div className={cn("relative overflow-hidden", rounded && "rounded-full", className)}>
        <Image src={product.image} alt={product.name} fill sizes={imageSizes} className="object-cover" />
      </div>
    );
  }
  return <MenuIcon name={product.icon} className={className} />;
}
