import { MenuIconName } from "@/types";

interface MenuIconProps {
  name: MenuIconName;
  className?: string;
}

/**
 * Gold vector medallions used as placeholder art for products that don't yet
 * have a real photo. Add a new case here if you introduce a new `icon` value
 * in data/products.ts.
 */
export function MenuIcon({ name, className }: MenuIconProps) {
  const stroke = "#C6992D";
  const fill = "#C6992D";

  switch (name) {
    case "circle":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <circle cx="20" cy="20" r="15" fill="none" stroke={stroke} strokeWidth="1.4" />
          <circle cx="20" cy="20" r="6" fill={fill} opacity="0.55" />
        </svg>
      );
    case "dot3":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <circle cx="20" cy="20" r="15" fill="none" stroke={stroke} strokeWidth="1.4" />
          <circle cx="14" cy="17" r="2" fill={fill} />
          <circle cx="24" cy="15" r="2" fill={fill} />
          <circle cx="20" cy="25" r="2" fill={fill} />
        </svg>
      );
    case "diamond":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <rect x="10" y="10" width="20" height="20" fill="none" stroke={stroke} strokeWidth="1.4" transform="rotate(45 20 20)" />
          <rect x="15" y="15" width="10" height="10" fill={fill} opacity="0.5" transform="rotate(45 20 20)" />
        </svg>
      );
    case "square":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <rect x="9" y="9" width="22" height="22" fill="none" stroke={stroke} strokeWidth="1.4" />
          <rect x="15" y="15" width="10" height="10" fill={fill} opacity="0.5" />
        </svg>
      );
    case "layered":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <rect x="8" y="14" width="24" height="6" fill="none" stroke={stroke} strokeWidth="1.3" />
          <rect x="8" y="21" width="24" height="6" fill="none" stroke={stroke} strokeWidth="1.3" />
          <rect x="8" y="14" width="24" height="6" fill={fill} opacity="0.35" />
        </svg>
      );
    case "oval":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <ellipse cx="20" cy="20" rx="15" ry="10" fill="none" stroke={stroke} strokeWidth="1.4" />
          <ellipse cx="20" cy="20" rx="7" ry="4" fill={fill} opacity="0.5" />
        </svg>
      );
    case "ball2":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <circle cx="15" cy="22" r="8" fill="none" stroke={stroke} strokeWidth="1.3" />
          <circle cx="25" cy="17" r="8" fill="none" stroke={stroke} strokeWidth="1.3" />
        </svg>
      );
    case "box":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <rect x="8" y="12" width="24" height="18" fill="none" stroke={stroke} strokeWidth="1.4" />
          <line x1="8" y1="18" x2="32" y2="18" stroke={stroke} strokeWidth="1" />
          <line x1="20" y1="12" x2="20" y2="30" stroke={stroke} strokeWidth="1" />
        </svg>
      );
    case "pretzel":
      return (
        <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
          <path
            d="M12 26 C12 14, 28 14, 28 22 C28 30, 16 30, 16 22 C16 16, 24 16, 24 24"
            fill="none"
            stroke={stroke}
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>
      );
    default:
      return null;
  }
}
