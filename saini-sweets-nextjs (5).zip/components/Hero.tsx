"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { Monogram } from "@/components/Monogram";
import { Button } from "@/components/ui/button";
import { business } from "@/data/business";

/** Luxury full-screen hero — homepage only. Content sourced from data/business.ts. */
export function Hero() {
  return (
    <section
      className="relative flex min-h-[640px] h-screen items-center justify-center overflow-hidden text-center"
    >
      <div className="absolute inset-0 scale-[1.08]">
        <Image
          src={business.heroImage}
          alt={`${business.name} storefront`}
          fill
          priority
          sizes="100vw"
          className="object-cover object-[center_30%] brightness-[0.55] saturate-[0.85]"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-ink/55 via-ink/35 to-ink/90" />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: "easeOut" }}
        className="relative z-10 max-w-3xl px-6"
      >
        <div className="mb-7 flex justify-center">
          <Monogram size={56} />
        </div>
        <h1 className="font-cormorant text-[clamp(48px,8vw,92px)] leading-[1] text-cream">
          {business.name}
        </h1>
        <div className="mt-4 font-cinzel text-xs uppercase tracking-[0.28em] text-gold">
          — Since {business.since} —
        </div>
        <p className="mx-auto mt-6 max-w-md font-serif text-lg italic text-cream-dim">
          {business.tagline}
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Button asChild variant="gold">
            <Link href="/menu">View Rate List</Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href="/about">Our Story</Link>
          </Button>
        </div>
      </motion.div>
    </section>
  );
}
