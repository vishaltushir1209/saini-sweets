"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Product } from "@/types";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/SectionHeading";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

interface FeaturedProductsProps {
  products: Product[];
}

/** Homepage section — shows items with `featured: true`, passed down from the page's server fetch. */
export function FeaturedProducts({ products }: FeaturedProductsProps) {
  const featured = products.filter((p) => p.featured && (p.available ?? true));

  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-6xl text-center">
        <SectionHeading eyebrow="Signature Mithai" title="Featured Products" />

        <ul className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-6">
          {featured.map((product, i) => (
            <motion.li key={product.id} {...fadeUpViewport} transition={fadeUpTransition(i, 0.06)}>
              <ProductCard product={product} />
            </motion.li>
          ))}
        </ul>

        <div className="mt-14">
          <Button asChild variant="gold">
            <Link href="/menu">View Full Rate List</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
