"use client";

import { MotionConfig } from "framer-motion";

/**
 * Wraps the app in a single MotionConfig so every Framer Motion animation
 * site-wide automatically respects the user's OS-level "reduce motion"
 * preference — without touching each individual animated component.
 */
export function MotionProvider({ children }: { children: React.ReactNode }) {
  return <MotionConfig reducedMotion="user">{children}</MotionConfig>;
}
