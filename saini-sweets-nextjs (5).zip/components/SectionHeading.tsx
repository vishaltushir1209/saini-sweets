import { cn } from "@/lib/utils";

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
  descriptionClassName?: string;
}

/**
 * The eyebrow + h2 (+ optional description) header repeated at the top of
 * FeaturedProducts, WhyChooseUs, FestivalOrders, Gallery, and Testimonials.
 * Extracted here so those five sections don't each redefine identical markup.
 */
export function SectionHeading({
  eyebrow,
  title,
  description,
  descriptionClassName,
}: SectionHeadingProps) {
  return (
    <>
      <span className="mb-2.5 block font-cinzel text-xs uppercase tracking-[0.28em] text-gold">
        {eyebrow}
      </span>
      <h2
        className={cn(
          "font-cormorant text-4xl text-cream md:text-[42px]",
          description ? "mb-4" : "mb-14"
        )}
      >
        {title}
      </h2>
      {description && (
        <p className={cn("mx-auto mb-14 text-cream-dim", descriptionClassName)}>
          {description}
        </p>
      )}
    </>
  );
}
