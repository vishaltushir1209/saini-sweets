"use client";

import { motion } from "framer-motion";
import { MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { whatsappLink, telLink } from "@/lib/utils";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

/** Contact CTA banner — WhatsApp + Call buttons. Used on the homepage and /contact page. */
export function ContactCTA() {
  return (
    <section className="border-y border-gold/20 bg-charcoal px-[5%] py-16 text-center md:py-20">
      <motion.div
        {...fadeUpViewport}
        transition={fadeUpTransition(0)}
        className="mx-auto max-w-2xl"
      >
        <span className="mb-2.5 block font-cinzel text-xs uppercase tracking-[0.28em] text-gold">
          Order Ahead
        </span>
        <h2 className="mb-4 font-cormorant text-3xl text-cream md:text-4xl">
          Ready To Order?
        </h2>
        <p className="mb-10 text-cream-dim">
          Message us on WhatsApp or call ahead — especially for festival and bulk orders.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Button asChild variant="whatsapp" size="lg">
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer">
              <MessageCircle size={16} aria-hidden="true" />
              WhatsApp Us
            </a>
          </Button>
          <Button asChild variant="call" size="lg">
            <a href={telLink()}>
              <Phone size={16} aria-hidden="true" />
              Call Now
            </a>
          </Button>
        </div>
      </motion.div>
    </section>
  );
}
