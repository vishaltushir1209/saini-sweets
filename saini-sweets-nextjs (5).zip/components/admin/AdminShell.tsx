"use client";

import { useState } from "react";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { AdminTopbar } from "@/components/admin/AdminTopbar";

interface AdminShellProps {
  children: React.ReactNode;
  userEmail?: string;
}

/** Holds the mobile sidebar's open/closed state and composes the admin layout. */
export function AdminShell({ children, userEmail }: AdminShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-ink text-cream">
      <AdminSidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <AdminTopbar
          userEmail={userEmail}
          mobileOpen={mobileOpen}
          onMenuToggle={() => setMobileOpen((v) => !v)}
        />
        <main id="admin-main-content" className="flex-1 px-6 py-8 md:px-10 md:py-10">
          {children}
        </main>
      </div>
    </div>
  );
}
