"use client";

import { useActionState } from "react";
import { Lock, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { loginAction } from "@/app/admin/login/actions";

export function LoginForm() {
  const [errorMessage, formAction, isPending] = useActionState(loginAction, undefined);

  return (
    <form action={formAction} className="mx-auto max-w-sm" noValidate>
      <div className="mb-6">
        <label
          htmlFor="email"
          className="mb-2 block font-cinzel text-xs uppercase tracking-[0.2em] text-gold"
        >
          Email
        </label>
        <div className="relative">
          <Mail
            size={16}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-gold-dim"
            aria-hidden="true"
          />
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="username"
            autoFocus
            className="w-full border border-gold-dim bg-charcoal py-3 pl-11 pr-4 text-cream placeholder:text-cream-dim/50 focus:border-gold focus:outline-none"
            placeholder="admin@example.com"
          />
        </div>
      </div>

      <div className="mb-6">
        <label
          htmlFor="password"
          className="mb-2 block font-cinzel text-xs uppercase tracking-[0.2em] text-gold"
        >
          Password
        </label>
        <div className="relative">
          <Lock
            size={16}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-gold-dim"
            aria-hidden="true"
          />
          <input
            id="password"
            name="password"
            type="password"
            required
            autoComplete="current-password"
            className="w-full border border-gold-dim bg-charcoal py-3 pl-11 pr-4 text-cream placeholder:text-cream-dim/50 focus:border-gold focus:outline-none"
            placeholder="••••••••"
          />
        </div>
      </div>

      {errorMessage && (
        <p role="alert" className="mb-6 border border-error/40 bg-error/10 px-4 py-3 text-sm text-cream">
          {errorMessage}
        </p>
      )}

      <Button type="submit" variant="solid" size="default" disabled={isPending} className="w-full">
        {isPending ? "Signing In…" : "Sign In"}
      </Button>
    </form>
  );
}
