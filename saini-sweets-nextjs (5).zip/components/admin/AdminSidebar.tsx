"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Monogram } from "@/components/Monogram";
import { business } from "@/data/business";
import { ADMIN_NAV_ITEMS } from "@/lib/admin-nav";

interface AdminSidebarProps {
  mobileOpen: boolean;
  onClose: () => void;
}

function SidebarBrand() {
  return (
    <div className="flex items-center gap-3 border-b border-gold/20 px-6 py-5">
      <Monogram size={26} />
      <span className="font-cinzel text-xs tracking-[0.16em] text-cream">
        {business.name.toUpperCase()}
      </span>
    </div>
  );
}

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <nav aria-label="Admin navigation" className="px-2 py-4">
      <ul className="space-y-1">
        {ADMIN_NAV_ITEMS.map((item) => {
          const active = pathname === item.href || (pathname?.startsWith(item.href + "/") ?? false);
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={active ? "page" : undefined}
                onClick={onNavigate}
                className={cn(
                  "flex items-center gap-3 border-l-2 px-4 py-2.5 font-cinzel text-xs uppercase tracking-[0.14em] transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light",
                  active
                    ? "border-gold bg-gold/10 text-gold-light"
                    : "border-transparent text-cream-dim hover:border-gold-dim hover:text-cream"
                )}
              >
                <item.icon size={16} aria-hidden="true" />
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/** Sidebar navigation — persistent on desktop, an off-canvas drawer on mobile. */
export function AdminSidebar({ mobileOpen, onClose }: AdminSidebarProps) {
  return (
    <>
      <aside className="hidden w-60 flex-none border-r border-gold/20 md:block">
        <SidebarBrand />
        <SidebarNav />
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-ink/80" onClick={onClose} aria-hidden="true" />
          <aside className="absolute inset-y-0 left-0 w-64 bg-ink">
            <div className="flex items-center justify-between border-b border-gold/20 px-6 py-5">
              <div className="flex items-center gap-3">
                <Monogram size={26} />
                <span className="font-cinzel text-xs tracking-[0.16em] text-cream">
                  {business.name.toUpperCase()}
                </span>
              </div>
              <button
                onClick={onClose}
                aria-label="Close menu"
                className="text-cream focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
              >
                <X size={20} />
              </button>
            </div>
            <SidebarNav onNavigate={onClose} />
          </aside>
        </div>
      )}
    </>
  );
}
