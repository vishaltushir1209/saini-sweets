import type { LucideIcon } from "lucide-react";

interface ComingSoonProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

/** Shared placeholder panel for admin sections that don't have functionality yet. */
export function ComingSoon({ icon: Icon, title, description }: ComingSoonProps) {
  return (
    <div className="flex flex-col items-center border border-gold/25 bg-charcoal px-6 py-20 text-center">
      <Icon size={32} className="mb-5 text-gold" aria-hidden="true" />
      <h2 className="font-cormorant text-2xl text-cream">{title}</h2>
      <p className="mt-2 max-w-sm text-sm text-cream-dim">{description}</p>
    </div>
  );
}
