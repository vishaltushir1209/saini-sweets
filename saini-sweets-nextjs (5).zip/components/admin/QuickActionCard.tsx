import Link from "next/link";
import { ArrowRight, type LucideIcon } from "lucide-react";

interface QuickActionCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

/** A clickable card linking to an admin section, shown in the dashboard's "Quick Actions". */
export function QuickActionCard({ icon: Icon, title, description, href }: QuickActionCardProps) {
  return (
    <Link
      href={href}
      className="group block border border-gold/25 bg-charcoal p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold hover:shadow-depth-md focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
    >
      <Icon size={22} className="mb-4 text-gold transition-transform duration-300 group-hover:scale-110" aria-hidden="true" />
      <h3 className="font-cormorant text-xl text-cream">{title}</h3>
      <p className="mt-1.5 text-sm text-cream-dim">{description}</p>
      <span className="mt-4 inline-flex items-center gap-1 font-cinzel text-xs uppercase tracking-[0.14em] text-gold-light">
        Manage
        <ArrowRight size={12} aria-hidden="true" />
      </span>
    </Link>
  );
}
