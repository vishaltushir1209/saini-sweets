"use client";

import { Menu, X, LogOut } from "lucide-react";
import { logoutAction } from "@/app/admin/actions";
import { Button } from "@/components/ui/button";

interface AdminTopbarProps {
  userEmail?: string;
  mobileOpen: boolean;
  onMenuToggle: () => void;
}

/** Top bar shown on every protected admin page — mobile nav toggle, admin identity, logout. */
export function AdminTopbar({ userEmail, mobileOpen, onMenuToggle }: AdminTopbarProps) {
  return (
    <header className="flex items-center justify-between gap-4 border-b border-gold/20 px-6 py-4 md:px-10">
      <button
        className="text-cream focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light md:hidden"
        aria-label="Toggle admin menu"
        aria-expanded={mobileOpen}
        onClick={onMenuToggle}
      >
        {mobileOpen ? <X size={22} /> : <Menu size={22} />}
      </button>

      <div className="ml-auto flex items-center gap-4">
        {userEmail && <span className="hidden text-sm text-cream-dim sm:inline">{userEmail}</span>}
        <form action={logoutAction}>
          <Button type="submit" variant="gold" size="sm">
            <LogOut size={14} aria-hidden="true" />
            Log Out
          </Button>
        </form>
      </div>
    </header>
  );
}
