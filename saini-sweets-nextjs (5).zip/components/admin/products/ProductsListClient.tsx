"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Search, Pencil, Trash2, Plus } from "lucide-react";
import { Product } from "@/types";
import { Button } from "@/components/ui/button";
import { ProductMedia } from "@/components/ProductMedia";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";
import { formatPrice, cn } from "@/lib/utils";
import { deleteProductAction, toggleProductFlagAction } from "@/app/admin/(protected)/products/actions";

interface ProductsListClientProps {
  initialProducts: Product[];
}

function ToggleSwitch({
  checked,
  label,
  onChange,
  disabled,
}: {
  checked: boolean;
  label: string;
  onChange: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={onChange}
      disabled={disabled}
      className={cn(
        "relative h-5 w-9 flex-none border transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light disabled:opacity-40",
        checked ? "border-gold bg-gold/30" : "border-gold-dim bg-transparent"
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 h-3.5 w-3.5 bg-gold transition-transform",
          checked ? "translate-x-4" : "translate-x-0.5"
        )}
        aria-hidden="true"
      />
    </button>
  );
}

export function ProductsListClient({ initialProducts }: ProductsListClientProps) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [isPending, startTransition] = useTransition();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return initialProducts;
    return initialProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        (p.category ?? "").toLowerCase().includes(q)
    );
  }, [initialProducts, query]);

  function handleToggle(id: string, field: "featured" | "available") {
    setPendingId(id + field);
    startTransition(async () => {
      await toggleProductFlagAction(id, field);
      router.refresh();
      setPendingId(null);
    });
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    const id = deleteTarget.id;
    startTransition(async () => {
      await deleteProductAction(id);
      router.refresh();
      setDeleteTarget(null);
    });
  }

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gold-dim" aria-hidden="true" />
          <label htmlFor="product-search" className="sr-only">
            Search products
          </label>
          <input
            id="product-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name or category…"
            className="w-full border border-gold-dim bg-charcoal py-2.5 pl-9 pr-4 text-sm text-cream placeholder:text-cream-dim/50 focus:border-gold focus:outline-none"
          />
        </div>
        <Button asChild variant="solid" size="sm">
          <Link href="/admin/products/new">
            <Plus size={14} aria-hidden="true" />
            Add Product
          </Link>
        </Button>
      </div>

      {filtered.length === 0 ? (
        <div className="border border-gold/25 bg-charcoal px-6 py-16 text-center text-cream-dim">
          No products match &ldquo;{query}&rdquo;.
        </div>
      ) : (
        <div className="overflow-x-auto border border-gold/25">
          <table className="w-full min-w-[720px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-gold/20 font-cinzel text-xs uppercase tracking-[0.12em] text-gold">
                <th scope="col" className="px-4 py-3">Photo</th>
                <th scope="col" className="px-4 py-3">Name</th>
                <th scope="col" className="px-4 py-3">Category</th>
                <th scope="col" className="px-4 py-3">Price</th>
                <th scope="col" className="px-4 py-3">Featured</th>
                <th scope="col" className="px-4 py-3">Available</th>
                <th scope="col" className="px-4 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((product) => (
                <tr key={product.id} className="border-b border-gold/10 last:border-b-0">
                  <td className="px-4 py-3">
                    <div className="h-10 w-10">
                      <ProductMedia product={product} className="h-full w-full" imageSizes="40px" rounded />
                    </div>
                  </td>
                  <td className="px-4 py-3 font-cormorant text-lg text-cream">{product.name}</td>
                  <td className="px-4 py-3 text-cream-dim">{product.category ?? "—"}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gold-light">
                    {formatPrice(product.price)}
                    <span className="text-cream-dim">/{product.unit}</span>
                  </td>
                  <td className="px-4 py-3">
                    <ToggleSwitch
                      checked={!!product.featured}
                      label={`Toggle featured for ${product.name}`}
                      onChange={() => handleToggle(product.id, "featured")}
                      disabled={isPending && pendingId === product.id + "featured"}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <ToggleSwitch
                      checked={product.available ?? true}
                      label={`Toggle availability for ${product.name}`}
                      onChange={() => handleToggle(product.id, "available")}
                      disabled={isPending && pendingId === product.id + "available"}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3">
                      <Link
                        href={`/admin/products/${product.id}/edit`}
                        aria-label={`Edit ${product.name}`}
                        className="text-gold-dim transition-colors hover:text-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
                      >
                        <Pencil size={16} />
                      </Link>
                      <button
                        type="button"
                        aria-label={`Delete ${product.name}`}
                        onClick={() => setDeleteTarget(product)}
                        className="text-gold-dim transition-colors hover:text-error focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete this product?"
        description={
          deleteTarget
            ? `"${deleteTarget.name}" will be permanently removed from the menu. This can't be undone.`
            : ""
        }
        confirmLabel="Delete"
        variant="destructive"
        isPending={isPending}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
