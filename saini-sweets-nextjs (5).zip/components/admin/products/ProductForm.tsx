"use client";

import { useActionState, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Product, PRODUCT_CATEGORIES, type MenuIconName } from "@/types";
import { Button } from "@/components/ui/button";
import { MenuIcon } from "@/components/icons/MenuIcons";
import type { ProductFormState } from "@/app/admin/(protected)/products/actions";

const MENU_ICON_OPTIONS: MenuIconName[] = [
  "circle",
  "dot3",
  "diamond",
  "square",
  "layered",
  "oval",
  "ball2",
  "box",
  "pretzel",
];

interface ProductFormProps {
  mode: "create" | "edit";
  product?: Product;
  action: (prevState: ProductFormState, formData: FormData) => Promise<ProductFormState>;
}

function FieldError({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <p role="alert" className="mt-1.5 text-xs text-error">
      {message}
    </p>
  );
}

const inputClasses =
  "w-full border border-gold-dim bg-ink px-4 py-2.5 text-cream placeholder:text-cream-dim/50 focus:border-gold focus:outline-none";
const labelClasses = "mb-2 block font-cinzel text-xs uppercase tracking-[0.2em] text-gold";

export function ProductForm({ mode, product, action }: ProductFormProps) {
  const [state, formAction, isPending] = useActionState(action, { errors: {} });
  const [selectedIcon, setSelectedIcon] = useState<MenuIconName>(product?.icon ?? "circle");

  return (
    <form action={formAction} className="max-w-2xl" noValidate>
      {state.errors.form && (
        <p role="alert" className="mb-6 border border-error/40 bg-error/10 px-4 py-3 text-sm">
          {state.errors.form}
        </p>
      )}

      <div className="mb-6">
        <label htmlFor="name" className={labelClasses}>
          Product Name
        </label>
        <input
          id="name"
          name="name"
          type="text"
          required
          defaultValue={product?.name}
          className={inputClasses}
          placeholder="e.g. Kaju Katli"
          aria-invalid={!!state.errors.name}
          aria-describedby={state.errors.name ? "name-error" : undefined}
        />
        {state.errors.name && <span id="name-error"><FieldError message={state.errors.name} /></span>}
      </div>

      <div className="mb-6 grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="price" className={labelClasses}>
            Price
          </label>
          <input
            id="price"
            name="price"
            type="number"
            min="1"
            step="1"
            required
            defaultValue={product?.price}
            className={inputClasses}
            placeholder="600"
            aria-invalid={!!state.errors.price}
            aria-describedby={state.errors.price ? "price-error" : undefined}
          />
          {state.errors.price && <span id="price-error"><FieldError message={state.errors.price} /></span>}
        </div>
        <div>
          <label htmlFor="unit" className={labelClasses}>
            Unit
          </label>
          <input
            id="unit"
            name="unit"
            type="text"
            required
            defaultValue={product?.unit ?? "kg"}
            className={inputClasses}
            placeholder="kg"
            aria-invalid={!!state.errors.unit}
            aria-describedby={state.errors.unit ? "unit-error" : undefined}
          />
          {state.errors.unit && <span id="unit-error"><FieldError message={state.errors.unit} /></span>}
        </div>
      </div>

      <div className="mb-6">
        <label htmlFor="category" className={labelClasses}>
          Category
        </label>
        <select
          id="category"
          name="category"
          required
          defaultValue={product?.category ?? ""}
          className={inputClasses}
          aria-invalid={!!state.errors.category}
          aria-describedby={state.errors.category ? "category-error" : undefined}
        >
          <option value="" disabled>
            Select a category
          </option>
          {PRODUCT_CATEGORIES.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
        {state.errors.category && <span id="category-error"><FieldError message={state.errors.category} /></span>}
      </div>

      <div className="mb-6">
        <label htmlFor="description" className={labelClasses}>
          Description <span className="normal-case text-cream-dim">(optional)</span>
        </label>
        <textarea
          id="description"
          name="description"
          rows={3}
          maxLength={500}
          defaultValue={product?.description}
          className={inputClasses}
          placeholder="A short description shown to customers…"
          aria-invalid={!!state.errors.description}
          aria-describedby={state.errors.description ? "description-error" : undefined}
        />
        {state.errors.description && <span id="description-error"><FieldError message={state.errors.description} /></span>}
      </div>

      <div className="mb-6">
        <label htmlFor="icon" className={labelClasses}>
          Fallback Icon
        </label>
        <div className="flex items-center gap-4">
          <select
            id="icon"
            name="icon"
            required
            value={selectedIcon}
            onChange={(e) => setSelectedIcon(e.target.value as MenuIconName)}
            className={inputClasses}
            aria-invalid={!!state.errors.icon}
            aria-describedby={state.errors.icon ? "icon-error" : undefined}
          >
            {MENU_ICON_OPTIONS.map((icon) => (
              <option key={icon} value={icon}>
                {icon}
              </option>
            ))}
          </select>
          <div className="h-11 w-11 flex-none border border-gold-dim p-1.5" aria-hidden="true">
            <MenuIcon name={selectedIcon} className="h-full w-full" />
          </div>
        </div>
        <p className="mt-1.5 text-xs text-cream-dim">
          Shown when no photo is uploaded below.
        </p>
        {state.errors.icon && <span id="icon-error"><FieldError message={state.errors.icon} /></span>}
      </div>

      <div className="mb-6">
        <label htmlFor="image" className={labelClasses}>
          Product Photo <span className="normal-case text-cream-dim">(optional, JPEG/PNG/WebP, max 5MB)</span>
        </label>
        {product?.image && (
          <div className="relative mb-3 h-24 w-24 overflow-hidden rounded-full border border-gold-dim">
            <Image src={product.image} alt="Current product photo" fill className="object-cover" />
          </div>
        )}
        <input
          id="image"
          name="image"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="w-full border border-gold-dim bg-ink px-4 py-2.5 text-sm text-cream file:mr-4 file:border-0 file:bg-gold file:px-3 file:py-1.5 file:font-cinzel file:text-xs file:uppercase file:tracking-wider file:text-ink"
          aria-invalid={!!state.errors.image}
          aria-describedby={state.errors.image ? "image-error" : undefined}
        />
        {state.errors.image && <span id="image-error"><FieldError message={state.errors.image} /></span>}
      </div>

      <div className="mb-8 flex flex-wrap gap-8">
        <label htmlFor="featured" className="flex items-center gap-2.5 text-sm text-cream">
          <input
            id="featured"
            name="featured"
            type="checkbox"
            defaultChecked={product?.featured ?? false}
            className="h-4 w-4 accent-gold"
          />
          Featured on homepage
        </label>
        <label htmlFor="available" className="flex items-center gap-2.5 text-sm text-cream">
          <input
            id="available"
            name="available"
            type="checkbox"
            defaultChecked={product?.available ?? true}
            className="h-4 w-4 accent-gold"
          />
          Available for sale
        </label>
      </div>

      <div className="flex gap-4">
        <Button type="submit" variant="solid" disabled={isPending}>
          {isPending ? "Saving…" : mode === "create" ? "Create Product" : "Save Changes"}
        </Button>
        <Button asChild variant="ghost">
          <Link href="/admin/products">Cancel</Link>
        </Button>
      </div>
    </form>
  );
}
