"use client";

import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  isPending?: boolean;
  /** "destructive" gives the confirm button a red treatment for delete-style actions. */
  variant?: "default" | "destructive";
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * Accessible confirmation modal built on the native <dialog> element, which
 * provides focus-trapping, Escape-to-close, and a backdrop for free — no
 * extra dependency needed for a single confirm dialog.
 */
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "Confirm",
  isPending = false,
  variant = "default",
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      dialog.showModal();
    } else if (!open && dialog.open) {
      dialog.close();
    }
  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      onCancel={(e) => {
        e.preventDefault();
        onCancel();
      }}
      aria-labelledby="confirm-dialog-title"
      aria-describedby="confirm-dialog-description"
      className="border border-gold/30 bg-charcoal p-0 text-cream backdrop:bg-ink/80"
    >
      <div className="w-[min(90vw,400px)] p-6">
        <h2 id="confirm-dialog-title" className="font-cormorant text-2xl text-cream">
          {title}
        </h2>
        <p id="confirm-dialog-description" className="mt-2 text-sm text-cream-dim">
          {description}
        </p>
        <div className="mt-6 flex justify-end gap-3">
          <Button type="button" variant="ghost" size="sm" onClick={onCancel} disabled={isPending}>
            Cancel
          </Button>
          <Button
            type="button"
            variant={variant === "destructive" ? "call" : "gold"}
            size="sm"
            onClick={onConfirm}
            disabled={isPending}
            className={variant === "destructive" ? "border-error text-error hover:bg-error hover:text-cream" : undefined}
          >
            {isPending ? "Please wait…" : confirmLabel}
          </Button>
        </div>
      </div>
    </dialog>
  );
}
