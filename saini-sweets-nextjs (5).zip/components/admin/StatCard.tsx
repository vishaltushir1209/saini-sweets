import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string;
}

/** A single overview stat on the dashboard. */
export function StatCard({ icon: Icon, label, value }: StatCardProps) {
  return (
    <div className="border border-gold/25 bg-charcoal p-6">
      <Icon size={20} className="mb-4 text-gold" aria-hidden="true" />
      <div className="font-cormorant text-3xl text-cream">{value}</div>
      <div className="mt-1 font-cinzel text-xs uppercase tracking-[0.14em] text-cream-dim">{label}</div>
    </div>
  );
}
