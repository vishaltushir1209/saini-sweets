"use client";

import { motion } from "framer-motion";
import { reviews } from "@/data/reviews";
import { ReviewCard } from "@/components/ReviewCard";
import { SectionHeading } from "@/components/SectionHeading";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

/**
 * Testimonials — data from data/reviews.ts.
 * ⚠️ Currently rendering SAMPLE placeholder reviews — replace data/reviews.ts
 * with real customer feedback before launch.
 */
export function Testimonials() {
  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-6xl text-center">
        <SectionHeading eyebrow="Customer Love" title="What People Say" />

        <ul className="grid gap-6 md:grid-cols-3">
          {reviews.map((review, i) => (
            <motion.li key={review.id} {...fadeUpViewport} transition={fadeUpTransition(i, 0.08)}>
              <ReviewCard review={review} />
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}
