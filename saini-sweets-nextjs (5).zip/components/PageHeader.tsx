"use client";

import { motion } from "framer-motion";
import { Monogram } from "@/components/Monogram";

interface PageHeaderProps {
  eyebrow: string;
  title: string;
  description?: string;
}

/** Shared banner used at the top of every inner page (About/Menu/Gallery/Contact). */
export function PageHeader({ eyebrow, title, description }: PageHeaderProps) {
  return (
    <section className="border-b border-gold/15 px-[5%] pb-16 pt-40 text-center md:pt-48">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      >
        <div className="mx-auto mb-6 flex justify-center">
          <Monogram size={40} />
        </div>
        <span className="mb-3 block font-cinzel text-xs uppercase tracking-[0.28em] text-gold">
          {eyebrow}
        </span>
        <h1 className="font-cormorant text-5xl text-cream md:text-6xl">{title}</h1>
        {description && (
          <p className="mx-auto mt-5 max-w-xl font-serif text-lg italic text-cream-dim">
            {description}
          </p>
        )}
      </motion.div>
    </section>
  );
}
