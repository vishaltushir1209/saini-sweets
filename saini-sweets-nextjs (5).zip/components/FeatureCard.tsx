import { Feature } from "@/types";
import { getIcon } from "@/lib/icons";

interface FeatureCardProps {
  feature: Feature;
}

/** Card System → Feature Card. Icon name comes from data/business.ts (whyChooseUs). */
export function FeatureCard({ feature }: FeatureCardProps) {
  const Icon = getIcon(feature.icon);

  return (
    <article className="text-center">
      <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center border border-gold">
        {Icon ? <Icon size={26} className="text-gold" aria-hidden="true" /> : null}
      </div>
      <h3 className="font-cinzel text-sm uppercase tracking-[0.12em] text-cream">
        {feature.title}
      </h3>
      <p className="mt-2.5 text-sm text-cream-dim">{feature.description}</p>
    </article>
  );
}
