import { Product } from "@/types";
import { formatPrice } from "@/lib/utils";
import { ProductMedia } from "@/components/ProductMedia";

interface ProductCardProps {
  product: Product;
}

/** Card System → Product Card. Used in the homepage "Featured Products" grid. */
export function ProductCard({ product }: ProductCardProps) {
  return (
    <article className="group border border-gold/25 bg-charcoal p-7 text-center shadow-depth-sm transition-all duration-300 hover:-translate-y-1 hover:border-gold hover:shadow-depth-md">
      <div className="mx-auto mb-5 h-16 w-16">
        <ProductMedia
          product={product}
          className="h-full w-full transition-transform duration-500 group-hover:scale-[1.06]"
          imageSizes="64px"
          rounded
        />
      </div>
      <h3 className="font-cormorant text-xl text-cream">{product.name}</h3>
      <p className="mt-2 font-cinzel text-sm text-gold-light">
        {formatPrice(product.price)}
        <span className="ml-0.5 text-[11px] text-cream-dim">/{product.unit}</span>
      </p>
    </article>
  );
}
