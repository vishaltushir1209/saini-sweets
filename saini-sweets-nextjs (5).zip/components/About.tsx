"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { business } from "@/data/business";
import { Button } from "@/components/ui/button";

interface AboutProps {
  /** "teaser" (homepage, shortened) or "full" (About page, complete story) */
  variant?: "teaser" | "full";
}

/** About Since {business.since} — reused as a homepage teaser and the full About page. */
export function About({ variant = "full" }: AboutProps) {
  const paragraphs =
    variant === "teaser"
      ? business.storyParagraphs.slice(0, 2)
      : business.storyParagraphs;

  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto grid max-w-6xl items-center gap-16 md:grid-cols-2 md:gap-20">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        >
          <span className="mb-3 block font-cinzel text-xs uppercase tracking-[0.28em] text-gold">
            Our Story
          </span>
          <h2 className="mb-6 font-cormorant text-4xl text-cream md:text-[42px]">
            {business.storyHeading}
          </h2>
          {paragraphs.map((para, i) => (
            <p key={i} className="mb-4 text-lg text-cream-dim">
              {para}
            </p>
          ))}

          <div className="mt-8 flex gap-10">
            {business.stats.map((stat) => (
              <div key={stat.label}>
                <div className="font-cormorant text-4xl leading-none text-gold-light">
                  {stat.value}
                </div>
                <div className="mt-1.5 font-cinzel text-[11px] uppercase tracking-[0.14em] text-cream-dim">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {variant === "teaser" && (
            <div className="mt-10">
              <Button asChild variant="gold" size="sm">
                <Link href="/about">Read Our Full Story</Link>
              </Button>
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="relative"
        >
          <div className="pointer-events-none absolute -left-4 -top-4 bottom-4 right-4 -z-10 border border-gold-dim" />
          <div className="relative h-[340px] w-full overflow-hidden border border-gold/35 md:h-[520px]">
            <Image
              src={business.aboutImage}
              alt={`${business.name} display counter`}
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
