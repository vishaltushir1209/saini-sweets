"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { business } from "@/data/business";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/SectionHeading";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

/** "Festival Orders" — content from business.festivals (data/business.ts). */
export function FestivalOrders() {
  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-6xl text-center">
        <SectionHeading
          eyebrow="Festival Orders"
          title="Celebrating With You"
          description="Bulk and gifting orders for every occasion — book ahead for festival season."
          descriptionClassName="max-w-lg"
        />

        <ul className="grid gap-6 md:grid-cols-3">
          {business.festivals.map((festival, i) => (
            <motion.li
              key={festival.id}
              {...fadeUpViewport}
              transition={fadeUpTransition(i, 0.08)}
              className="group relative h-72 overflow-hidden border border-gold/25"
            >
              <Image
                src={festival.image}
                alt={festival.name}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/30 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 text-left">
                <h3 className="font-cormorant text-2xl text-cream">{festival.name}</h3>
                <p className="mt-1.5 text-sm text-cream-dim">{festival.tagline}</p>
              </div>
            </motion.li>
          ))}
        </ul>

        <div className="mt-14">
          <Button asChild variant="secondary">
            <Link href="/contact">Enquire For Festival Orders</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
