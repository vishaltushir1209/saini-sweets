"use client";

import { motion } from "framer-motion";
import { business } from "@/data/business";
import { FeatureCard } from "@/components/FeatureCard";
import { SectionHeading } from "@/components/SectionHeading";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

/** "Why Choose Us" — content from business.whyChooseUs (data/business.ts). */
export function WhyChooseUs() {
  return (
    <section className="bg-charcoal px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-6xl text-center">
        <SectionHeading eyebrow="Why Choose Us" title="What Sets Us Apart" />

        <ul className="grid grid-cols-2 gap-10 md:grid-cols-4">
          {business.whyChooseUs.map((feature, i) => (
            <motion.li key={feature.id} {...fadeUpViewport} transition={fadeUpTransition(i, 0.08)}>
              <FeatureCard feature={feature} />
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}
