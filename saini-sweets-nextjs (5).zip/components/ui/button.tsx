import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-cinzel text-xs uppercase tracking-[0.2em] transition-all duration-300 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light active:scale-[0.97]",
  {
    variants: {
      variant: {
        gold: "border border-gold text-gold-light hover:bg-gold hover:text-ink hover:shadow-gold-glow",
        solid: "bg-gold text-ink hover:bg-gold-light hover:shadow-gold-glow",
        secondary: "bg-maroon text-cream border border-gold-dim hover:border-gold hover:bg-maroon/80",
        ghost: "text-cream-dim hover:text-gold-light",
        whatsapp: "rounded-full bg-whatsapp text-ink hover:bg-[#20BD5A] hover:shadow-depth-sm",
        call: "border border-gold text-gold-light hover:bg-gold hover:text-ink",
      },
      size: {
        default: "px-10 py-4",
        sm: "px-6 py-2.5",
        lg: "px-12 py-5",
      },
    },
    defaultVariants: {
      variant: "gold",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
