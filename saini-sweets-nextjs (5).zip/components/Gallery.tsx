"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { galleryImages } from "@/data/gallery";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/SectionHeading";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

interface GalleryProps {
  /** Show only the first N images (homepage preview). Omit to show all (/gallery page). */
  limit?: number;
  /** Show the "View Full Gallery" CTA — used on the homepage preview only. */
  showCta?: boolean;
}

/** Gallery grid — reused as the homepage preview and the full /gallery page. Data: data/gallery.ts. */
export function Gallery({ limit, showCta = false }: GalleryProps) {
  const images = limit ? galleryImages.slice(0, limit) : galleryImages;

  return (
    <section className="px-[5%] py-28 md:py-32">
      <div className="mx-auto max-w-6xl text-center">
        <SectionHeading eyebrow="Inside The Shop" title="Gallery" />

        <ul className="grid grid-cols-2 grid-rows-3 gap-3.5 md:grid-cols-3 md:grid-rows-2">
          {images.map((img, i) => (
            <motion.li
              key={img.id}
              {...fadeUpViewport}
              transition={fadeUpTransition(i, 0.06)}
              className={cn(
                "group relative overflow-hidden border border-gold/25",
                img.size === "large"
                  ? "col-span-2 h-[220px] md:col-span-1 md:row-span-2 md:h-auto"
                  : "h-[180px] md:h-[260px]"
              )}
            >
              <Image
                src={img.src}
                alt={img.alt}
                fill
                sizes="(max-width: 768px) 50vw, 33vw"
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
              />
            </motion.li>
          ))}
        </ul>

        {showCta && (
          <div className="mt-14">
            <Button asChild variant="gold">
              <Link href="/gallery">View Full Gallery</Link>
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
