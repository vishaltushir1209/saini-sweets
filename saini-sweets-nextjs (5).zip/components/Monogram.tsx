import { cn } from "@/lib/utils";

interface MonogramProps {
  /** Pixel size of the outer square. Defaults to 34 (nav size). */
  size?: number;
  className?: string;
}

/**
 * The interlocking "S S" square motif from the Saini Sweets logo.
 * Reused across the header, hero, and footer as the site's signature element.
 */
export function Monogram({ size = 34, className }: MonogramProps) {
  const inner = Math.round(size * 0.65);
  return (
    <span
      className={cn("relative inline-flex", className)}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <span
        className="absolute top-0 left-0 border-[1.6px] border-gold"
        style={{ width: inner, height: inner }}
      />
      <span
        className="absolute bottom-0 right-0 border-[1.6px] border-gold"
        style={{ width: inner, height: inner }}
      />
    </span>
  );
}
