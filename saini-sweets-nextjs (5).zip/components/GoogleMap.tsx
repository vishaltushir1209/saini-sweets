"use client";

import { motion } from "framer-motion";
import { business } from "@/data/business";
import { fadeUpViewport, fadeUpTransition } from "@/lib/animations";

/**
 * Embedded map. Uses business.mapEmbedSrc (data/business.ts) — currently a
 * generic placeholder search; replace with a real Google Maps "Embed a map" URL.
 * Wrapped in a responsive aspect-ratio box so it scales cleanly at every breakpoint.
 */
export function GoogleMap() {
  return (
    <section className="px-[5%] pb-28 md:pb-32">
      <div className="mx-auto max-w-6xl">
        <motion.div
          {...fadeUpViewport}
          transition={fadeUpTransition(0)}
          className="relative aspect-[16/9] w-full overflow-hidden border border-gold/25 sm:aspect-[21/9]"
        >
          <iframe
            src={business.mapEmbedSrc}
            title={`${business.name} location map`}
            className="absolute inset-0 h-full w-full"
            style={{ border: 0, filter: "grayscale(0.3) contrast(1.05)" }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </section>
  );
}
