import Link from "next/link";
import { Phone, Mail, MapPin } from "lucide-react";
import { Monogram } from "@/components/Monogram";
import { business } from "@/data/business";
import { getIcon } from "@/lib/icons";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-gold/20 px-[5%] pb-8 pt-16">
      <div className="mx-auto grid max-w-6xl gap-12 md:grid-cols-4">
        <div>
          <div className="mb-3 flex items-center gap-3">
            <Monogram size={30} />
            <span className="font-cinzel text-sm tracking-[0.2em] text-cream">
              {business.name.toUpperCase()}
            </span>
          </div>
          <p className="text-sm text-cream-dim">{business.shortTagline}</p>
        </div>

        <div>
          <h3 className="mb-4 font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
            Explore
          </h3>
          <ul className="space-y-2.5">
            {business.navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="text-sm text-cream-dim transition-colors hover:text-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="mb-4 font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
            Contact
          </h3>
          <ul className="space-y-3 text-sm text-cream-dim">
            <li className="flex items-start gap-2">
              <MapPin size={16} className="mt-0.5 flex-none text-gold" aria-hidden="true" />
              <span>{business.address}</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone size={16} className="flex-none text-gold" aria-hidden="true" />
              <span>{business.phone}</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail size={16} className="flex-none text-gold" aria-hidden="true" />
              <span>{business.email}</span>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="mb-4 font-cinzel text-xs uppercase tracking-[0.2em] text-gold">
            Follow
          </h3>
          <div className="flex gap-4">
            {business.socials.map((social) => {
              const Icon = getIcon(social.icon);
              return (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="flex h-9 w-9 items-center justify-center border border-gold-dim text-gold transition-colors hover:border-gold hover:text-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
                >
                  {Icon ? <Icon size={16} aria-hidden="true" /> : null}
                </a>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mx-auto mt-14 max-w-6xl border-t border-gold/10 pt-6 text-center text-xs text-cream-dim opacity-60">
        &copy; {year} {business.name}. All rights reserved.
      </div>
    </footer>
  );
}
