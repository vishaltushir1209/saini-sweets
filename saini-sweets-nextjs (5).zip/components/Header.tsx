"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useScrollHeader } from "@/hooks/useScrollHeader";
import { Monogram } from "@/components/Monogram";
import { Button } from "@/components/ui/button";
import { business } from "@/data/business";

/**
 * Premium sticky navbar — shared across every page via app/layout.tsx.
 * Route links come from `business.navLinks` (data/business.ts), so adding a
 * page later only means adding one object there.
 */
export function Header() {
  const scrolled = useScrollHeader(40);
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 flex items-center justify-between px-[5%] py-5 transition-all duration-300",
        scrolled
          ? "bg-ink/95 py-3 border-b border-gold/20"
          : "bg-gradient-to-b from-ink/90 to-transparent"
      )}
    >
      <Link href="/" className={cn("flex items-center gap-3 transition-opacity hover:opacity-80", "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light")}>
        <Monogram size={34} />
        <span className="font-cinzel text-sm tracking-[0.18em] text-cream">
          {business.name}
        </span>
      </Link>

      <nav className="hidden md:block">
        <ul className="flex items-center gap-9">
          {business.navLinks.map((link) => {
            const active = pathname === link.href;
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "font-cinzel text-xs uppercase tracking-[0.16em] transition-colors hover:text-gold-light",
                    "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light",
                    active ? "text-gold-light" : "text-cream-dim"
                  )}
                >
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="hidden md:block">
        <Button asChild variant="gold" size="sm">
          <Link href="/contact">Order Now</Link>
        </Button>
      </div>

      <button
        className="text-cream md:hidden focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
        aria-label="Toggle menu"
        aria-expanded={mobileOpen}
        onClick={() => setMobileOpen((v) => !v)}
      >
        {mobileOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {mobileOpen && (
        <nav className="absolute left-0 right-0 top-full border-t border-gold/20 bg-ink/98 md:hidden">
          <ul className="flex flex-col items-center gap-6 py-8">
            {business.navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="font-cinzel text-xs uppercase tracking-[0.16em] text-cream-dim transition-colors hover:text-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-light"
                >
                  {link.label}
                </Link>
              </li>
            ))}
            <li>
              <Button asChild variant="gold" size="sm" onClick={() => setMobileOpen(false)}>
                <Link href="/contact">Order Now</Link>
              </Button>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
