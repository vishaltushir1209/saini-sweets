// Generates a bcrypt hash for the single admin password.
// Usage: node scripts/generate-admin-hash.mjs "your-chosen-password"
// Copy the output into ADMIN_PASSWORD_HASH in .env.local — never store the
// plain password anywhere in the project.

import bcrypt from "bcryptjs";

const password = process.argv[2];

if (!password) {
  console.error('Usage: node scripts/generate-admin-hash.mjs "your-chosen-password"');
  process.exit(1);
}

const hash = bcrypt.hashSync(password, 12);
console.log("\nADMIN_PASSWORD_HASH=" + hash + "\n");
console.log("Copy the line above into your .env.local file.");
