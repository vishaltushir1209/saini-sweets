/**
 * Shared Framer Motion presets for the repeated "fade up on scroll" pattern
 * used across FeaturedProducts, WhyChooseUs, FestivalOrders, Gallery, and
 * Testimonials. Centralizing these avoids re-typing identical animation
 * objects in every grid section.
 */
export const fadeUpViewport = {
  initial: { opacity: 0, y: 16 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
} as const;

/** Staggered transition for a grid item at `index`, spaced by `delayStep` seconds. */
export function fadeUpTransition(index: number, delayStep = 0.06) {
  return {
    duration: 0.5,
    delay: index * delayStep,
    ease: "easeOut" as const,
  };
}
