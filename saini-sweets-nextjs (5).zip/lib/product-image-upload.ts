import fs from "node:fs/promises";
import path from "node:path";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads", "products");
const MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
const ALLOWED_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

export interface ImageUploadResult {
  path?: string;
  error?: string;
}

/**
 * Saves an uploaded product image to /public/uploads/products and returns
 * its public path. Same deployment caveat as products-store.ts: requires a
 * persistent, writable filesystem (works on a traditional Node server, not
 * on ephemeral serverless platforms).
 */
export async function saveProductImage(file: File, slugHint: string): Promise<ImageUploadResult> {
  if (file.size === 0) {
    return {};
  }
  if (file.size > MAX_SIZE_BYTES) {
    return { error: "Image must be 5MB or smaller." };
  }
  const extension = ALLOWED_TYPES[file.type];
  if (!extension) {
    return { error: "Image must be a JPEG, PNG, or WebP file." };
  }

  await fs.mkdir(UPLOAD_DIR, { recursive: true });

  const safeSlug = slugHint.toLowerCase().replace(/[^a-z0-9-]+/g, "-") || "product";
  const filename = `${safeSlug}-${Date.now()}.${extension}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(path.join(UPLOAD_DIR, filename), buffer);

  return { path: `/uploads/products/${filename}` };
}
