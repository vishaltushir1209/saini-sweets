import fs from "node:fs/promises";
import path from "node:path";
import { Product } from "@/types";

/**
 * Product persistence layer, backed by a JSON file on disk. Server-only —
 * every export here uses Node's `fs` module and must only be called from
 * Server Components or Server Actions, never from "use client" files.
 *
 * ⚠️ Deployment note: this works correctly on a traditional Node.js server
 * (e.g. `next start` on a VPS) where the filesystem persists between
 * requests. It will NOT persist writes on ephemeral/serverless platforms
 * (e.g. Vercel's default runtime) — each invocation may get a fresh
 * filesystem. If deploying there, swap this module for a real database.
 */

const DATA_FILE = path.join(process.cwd(), "data", "products.json");

async function readAll(): Promise<Product[]> {
  const raw = await fs.readFile(DATA_FILE, "utf-8");
  return JSON.parse(raw) as Product[];
}

async function writeAll(products: Product[]): Promise<void> {
  await fs.writeFile(DATA_FILE, JSON.stringify(products, null, 2) + "\n", "utf-8");
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

async function uniqueId(base: string, existing: Product[]): Promise<string> {
  let id = base || "product";
  let suffix = 2;
  const taken = new Set(existing.map((p) => p.id));
  while (taken.has(id)) {
    id = `${base}-${suffix}`;
    suffix += 1;
  }
  return id;
}

export type ProductInput = Omit<Product, "id">;

export async function getProducts(): Promise<Product[]> {
  return readAll();
}

export async function getProduct(id: string): Promise<Product | undefined> {
  const products = await readAll();
  return products.find((p) => p.id === id);
}

export async function createProduct(input: ProductInput): Promise<Product> {
  const products = await readAll();
  const id = await uniqueId(slugify(input.name), products);
  const product: Product = { id, ...input };
  products.push(product);
  await writeAll(products);
  return product;
}

export async function updateProduct(id: string, input: Partial<ProductInput>): Promise<Product | null> {
  const products = await readAll();
  const index = products.findIndex((p) => p.id === id);
  if (index === -1) return null;
  products[index] = { ...products[index], ...input, id };
  await writeAll(products);
  return products[index];
}

export async function deleteProduct(id: string): Promise<boolean> {
  const products = await readAll();
  const next = products.filter((p) => p.id !== id);
  if (next.length === products.length) return false;
  await writeAll(next);
  return true;
}
