import { PRODUCT_CATEGORIES, type MenuIconName, type ProductCategory } from "@/types";
import type { ProductInput } from "@/lib/products-store";

const MENU_ICONS: MenuIconName[] = [
  "circle",
  "dot3",
  "diamond",
  "square",
  "layered",
  "oval",
  "ball2",
  "box",
  "pretzel",
];

export interface ProductValidationResult {
  errors: Record<string, string>;
  data?: ProductInput;
}

/** Shared validation for both create and update product forms. */
export function validateProductInput(formData: FormData): ProductValidationResult {
  const errors: Record<string, string> = {};

  const name = String(formData.get("name") ?? "").trim();
  if (!name) {
    errors.name = "Product name is required.";
  } else if (name.length < 2 || name.length > 80) {
    errors.name = "Product name must be between 2 and 80 characters.";
  }

  const priceRaw = String(formData.get("price") ?? "").trim();
  const price = Number(priceRaw);
  if (!priceRaw) {
    errors.price = "Price is required.";
  } else if (!Number.isFinite(price) || price <= 0) {
    errors.price = "Price must be a positive number.";
  } else if (price > 100000) {
    errors.price = "Price seems too high — please double-check.";
  }

  const unit = String(formData.get("unit") ?? "").trim();
  if (!unit) {
    errors.unit = "Unit is required (e.g. kg, piece, box).";
  } else if (unit.length > 20) {
    errors.unit = "Unit must be 20 characters or fewer.";
  }

  const category = String(formData.get("category") ?? "").trim();
  if (!category) {
    errors.category = "Please choose a category.";
  } else if (!PRODUCT_CATEGORIES.includes(category as ProductCategory)) {
    errors.category = "Please choose a valid category.";
  }

  const icon = String(formData.get("icon") ?? "").trim();
  if (!icon) {
    errors.icon = "Please choose a fallback icon.";
  } else if (!MENU_ICONS.includes(icon as MenuIconName)) {
    errors.icon = "Please choose a valid icon.";
  }

  const description = String(formData.get("description") ?? "").trim();
  if (description.length > 500) {
    errors.description = "Description must be 500 characters or fewer.";
  }

  if (Object.keys(errors).length > 0) {
    return { errors };
  }

  return {
    errors: {},
    data: {
      name,
      price,
      unit,
      category: category as ProductCategory,
      icon: icon as MenuIconName,
      description: description || undefined,
      featured: formData.get("featured") === "on",
      available: formData.get("available") === "on",
    },
  };
}
