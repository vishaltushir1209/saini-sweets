import * as LucideIcons from "lucide-react";
import type { LucideIcon } from "lucide-react";

/**
 * Resolve a Lucide icon component by its exported name (e.g. "Award", "Instagram").
 * Centralizes the one wildcard lucide-react import needed for data-driven icon
 * lookups (business.whyChooseUs[].icon, business.socials[].icon) so it only
 * happens in one place instead of being duplicated per component.
 * Returns null if the name doesn't match a real export (e.g. a typo in data).
 */
export function getIcon(name: string): LucideIcon | null {
  const icon = (LucideIcons as unknown as Record<string, LucideIcon>)[name];
  return icon ?? null;
}
