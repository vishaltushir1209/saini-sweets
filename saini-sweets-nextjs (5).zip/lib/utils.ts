import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { business } from "@/data/business";

/** Merge Tailwind classes safely, resolving conflicting utility classes. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a number as an Indian Rupee price string, e.g. 600 -> "₹600" */
export function formatPrice(value: number): string {
  return `₹${value.toLocaleString("en-IN")}`;
}

/** Build a wa.me deep link using the business's WhatsApp number + default message. */
export function whatsappLink(message?: string): string {
  const text = encodeURIComponent(message ?? business.whatsappMessage);
  return `https://wa.me/${business.whatsappNumber}?text=${text}`;
}

/** Build a tel: link from the business phone number. */
export function telLink(): string {
  return `tel:${business.phone.replace(/[^+\d]/g, "")}`;
}
